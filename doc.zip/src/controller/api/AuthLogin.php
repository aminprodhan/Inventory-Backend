<?php 

     use App\controller\models\User;

     $username=$_POST["username"];
     $passwrod=$_POST["passwrod"];
     $info=User::isValidUser($username,$passwrod);
     echo json_encode($info);

?>