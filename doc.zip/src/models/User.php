<?php
    require ('../config.php');
    class User{
        public static function isValidUser($username,$password){
            $status=0;$msg="Something went wrong";$data=array();

            if(empty($username))
                $msg="User name is required!!";
            else if(empty($password))
                $msg="Password is required!!";
            else {
                $sql = "SELECT * FROM `users` WHERE status=1 and user_name='" . $username . "' and password='" . $username . "'";
                $result_data = $con->query($sql)->fetch_assoc();
                if (!empty($result_data["id"]))
                    {
                        $data=$result_data;$msg="Success";$status=1;
                    }

            }
            $ara=array(
                "status" => 0,
                "msg" => $msg,
                "uinfo"=> (object)$data
            );
            return $ara;
        }
    }
?>  